/*============
  * A Simple Test 
  *============
  */

#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED_Test.h"
#include "tests.h"
#include "os.h"
#include <util/delay.h>
  
void Producer() 
{
    for(;;){   
        debug_led(5);
        PID Consumer_PID = Task_GetArg();
        unsigned int send_msg = 5;
        Msg_Send( Consumer_PID, '@', &send_msg);
    }
}

void Producer2() 
{
    for(;;){   
        debug_led(1);
        debug_led(2);
        debug_led(4);
        PID Consumer_PID = Task_GetArg();
        unsigned int send_msg = 5;
        Msg_Send( Consumer_PID, '(', &send_msg);
    }
}

void Producer3() 
{
    for(;;){   
        debug_led(5);
        PID Consumer_PID = Task_GetArg();
        unsigned int send_msg = 5;
        Msg_ASend( Consumer_PID, '@', send_msg);
        //Task_Next();
    }
}

void Consumer() 
{
    for(;;){
        debug_led(4);
        unsigned int rec_msg = 0;
        PID Producer_PID = Msg_Recv( '@', &rec_msg );
        Msg_Rply( Producer_PID, rec_msg );
    }
}

void Creator()
{
    debug_led(1);
    PID Consumer_PID = Task_Create_RR( Consumer, 1 );
    debug_led(2);
    debug_led(Consumer_PID);
    PID Producer_PID = Task_Create_RR( Producer, Consumer_PID );
    PID Producer_PID2 = Task_Create_RR( Producer2, Consumer_PID );
    for(;;){
        Task_Next();
    }
}

void Creator2()
{
    debug_led(1);
    PID Consumer_PID = Task_Create_RR( Consumer, 1 );
    debug_led(2);
    debug_led(Consumer_PID);
    PID Producer_PID = Task_Create_RR( Producer3, Consumer_PID );
    debug_led(Producer_PID);
    for(;;){
        Task_Next();
    }
}

/**
  * A cooperative "Ping" task.
  * Added testing code for LEDs.
  */
void Ping() 
{
    init_LED_H3();
    for(;;) {
        enable_LED(&PORTH, 3);
        disable_LED(&PORTE, 3);
        disable_LED(&PORTG, 5);
        disable_LED(&PORTE, 5);
    }
}


/**
  * A cooperative "Pong" task.
  * Added testing code for LEDs.
  */
void Pong()
{
  init_LED_E3();
  for(;;) {
    enable_LED(&PORTE, 3);
    disable_LED(&PORTH, 3);
    disable_LED(&PORTG, 5);
    disable_LED(&PORTE, 5);
  }
}

void Paddle()
{
    init_LED_G5();
    for(;;)
    {
    //debug_led(1);
    enable_LED(&PORTG, 5);
    disable_LED(&PORTE, 3);
    disable_LED(&PORTH, 3);
    disable_LED(&PORTE, 5);

    //int x;
    //for (x = 0; x < (Now() / 10); x++)
    //{
    //    _delay_ms(1);
    //}
    _delay_ms(20);
    disable_LED(&PORTG, 5);

    Task_Next();
    }
}

void Puddle()
{
    init_LED_E5();
    for(;;)
    {
    debug_led(5);
    enable_LED(&PORTE, 5);
    disable_LED(&PORTE, 3);
    disable_LED(&PORTH, 3);

    _delay_ms(100);
    disable_LED(&PORTE, 5);

    Task_Next();
    }
}

void Test_Now()
{
    int threshold = 0;
    int x = 0;
    for(;;){
        if (Now() > threshold)
        {
            debug_led(x);
            threshold += 123;
            x += 1;
        }
    }
}

void a_main(){
    //ROUND ROBIN WITH PERIODIC AND SYSTEM
    /*Task_Create_RR( Pong, 100 );
    Task_Create_RR( Ping, 100 );
    Task_Create_Period( Paddle, 100, 100, 3, 1);
    Task_Create_System( Puddle, 100 ); */
    
    
    //MULTIPLE PRODUCERS ONE CONSUMER, ONE PRODUCER
    //DOES NOT MATCH MASK, OTHER DOES
    /*Task_Create_RR( Pong, 100 );
    Task_Create_System( Creator, 100 ); */
    
    //TEST ASYNC SEND
    //Task_Create_System( Creator2, 100 );
    
    //PERIODIC TASK TAKES LONGER THAN WCETI (os abort)
    //Task_Create_Period( Paddle, 100, 100, 1, 1);

    //CREATE MORE TASKS THAN THERE ARE SPACES FOR
    /*int x;
    for (x = 0; x < MAXTHREAD; x++){
        Task_Create_RR( Pong, 100 );
    }
    Task_Create_RR( Ping, 100 ); */
    
    //TEST NOW FUNCTION
    Task_Create_RR(Test_Now, 100);
    
    //IDLE FROM NOW ON
    for(;;){
        Task_Next();
    }
}

//FIX DETECTING WHEN TWO PERIODIC TASKS COLLIDE




