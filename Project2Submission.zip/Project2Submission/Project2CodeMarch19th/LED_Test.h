/**
 * \file LED_Test.h
 * \brief Constants and functions for controlling LEDs on a AT90USBKey
 * 
 * \mainpage Constants and functions for controlling the state of the onboard
 *  LEDs on the AT90USBKey. 
 *
 * \author Alexander M. Hoole
 * \date October 2006
 */

void bit_reset(volatile uint8_t *pin_register, unsigned int offset);
void bit_set(volatile uint8_t * pin_register, unsigned int offset);
void enable_LED(volatile uint8_t * port_set, unsigned int offset);
void init_LED_E3(void);
void init_LED_E5(void);
void init_LED_H3(void);
void init_LED_G5(void);
void disable_LED(volatile uint8_t * port_set, unsigned int offset);
