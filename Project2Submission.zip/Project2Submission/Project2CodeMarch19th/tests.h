void Producer();

void Producer2();

void Producer3();

void Consumer();

void Creator();

void Creator2();

void Ping();

void Pong();

void Paddle();

void Puddle();

void a_main();