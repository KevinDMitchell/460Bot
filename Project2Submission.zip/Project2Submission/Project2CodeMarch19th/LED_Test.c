#include <avr/io.h>
#include "LED_Test.h"
/**
 * \file LED_Test.c
 * \brief Small set of test functions for controlling LEDs on a AT90USBKey
 * 
 * \mainpage Simple set of functions to control the state of the onboard
 *  LEDs on the AT90USBKey. 
 *
 * \author Alexander M. Hoole
 * \date October 2006
 */
 
 // SET BIT AT OFFSET TO 0
 void bit_reset(volatile uint8_t *pin_register, unsigned int offset)
 {
    *pin_register &= ~(1 << offset);
 }
 
 // SET BIT AT OFFSET TO 1
 void bit_set(volatile uint8_t * pin_register, unsigned int offset)
 {
    *pin_register |= (1 << offset);
 }
 
 // SWAP BIT?
 void bit_swap(volatile uint8_t pin_register, unsigned int offset)
 {
    pin_register = pin_register ^ (1 << offset);
 }

void init_LED_E3(void)
{
    bit_set(&DDRE, 3);       //Set LED to output (pin 5)
    bit_reset(&PORTE, 3);    //Initialize port to LOW (turn off LEDs)
}

void init_LED_E5(void)
{
    bit_set(&DDRE, 5);       //Set LED to output (pin 5)
    bit_reset(&PORTE, 5);    //Initialize port to LOW (turn off LEDs)
}

void init_LED_H3(void)
{
    bit_set(&DDRH, 3); 		//Set LED to output (pins 6)
    bit_reset(&PORTH, 3);    //Initialize port to LOW (turn off LEDs
    
}

void init_LED_G5(void)
{
    bit_set(&DDRG, 5);       //Set LED to output (pin 5)
    bit_reset(&PORTG, 5);    //Initialize port to LOW (turn off LEDs)
}

void enable_LED(volatile uint8_t * port_set, unsigned int offset)
{
    bit_set(port_set, offset);
	//port = 0xFF;//mask;		//Initialize port to high
}

void disable_LED(volatile uint8_t * port_set, unsigned int offset)
{
    bit_reset(port_set, offset);
    //port = 0xFF;	//Initialize port to high
}
