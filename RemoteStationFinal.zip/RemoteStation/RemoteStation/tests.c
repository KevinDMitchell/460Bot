/*============
  * A Simple Test 
  *============
  */

#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED_Test.h"
#include "tests.h"
#include "os.h"
#include <util/delay.h>
#include "uart.h"

#define MAXLINE			81
#define CLOCK_8MHZ()	CLKPR = _BV(CLKPCE); CLKPR = 0x00;

//GLOBAL VARIABLES
int laser_state;
int servo_x_pos;
int servo_y_pos;
char roomba_command;
  
void Producer() 
{
    for(;;){   
        debug_led(5);
        PID Consumer_PID = Task_GetArg();
        unsigned int send_msg = 5;
        Msg_Send( Consumer_PID, '@', &send_msg);
    }
}

void Producer2() 
{
    for(;;){   
        debug_led(1);
        debug_led(2);
        debug_led(4);
        PID Consumer_PID = Task_GetArg();
        unsigned int send_msg = 5;
        Msg_Send( Consumer_PID, '(', &send_msg);
    }
}

void Producer3() 
{
    for(;;){   
        debug_led(5);
        PID Consumer_PID = Task_GetArg();
        unsigned int send_msg = 5;
        Msg_ASend( Consumer_PID, '@', send_msg);
        //Task_Next();
    }
}

void Consumer() 
{
    for(;;){
        debug_led(4);
        unsigned int rec_msg = 0;
        PID Producer_PID = Msg_Recv( '@', &rec_msg );
        Msg_Rply( Producer_PID, rec_msg );
    }
}

void Creator()
{
    debug_led(1);
    PID Consumer_PID = Task_Create_RR( Consumer, 1 );
    debug_led(2);
    debug_led(Consumer_PID);
    PID Producer_PID = Task_Create_RR( Producer, Consumer_PID );
    PID Producer_PID2 = Task_Create_RR( Producer2, Consumer_PID );
    for(;;){
        Task_Next();
    }
}

void Creator2()
{
    debug_led(1);
    PID Consumer_PID = Task_Create_RR( Consumer, 1 );
    debug_led(2);
    debug_led(Consumer_PID);
    PID Producer_PID = Task_Create_RR( Producer3, Consumer_PID );
    debug_led(Producer_PID);
    for(;;){
        Task_Next();
    }
}

/**
  * A cooperative "Ping" task.
  * Added testing code for LEDs.
  */
void Ping() 
{
    init_LED_H3();
    for(;;) {
        enable_LED(&PORTH, 3);
        disable_LED(&PORTE, 3);
        disable_LED(&PORTG, 5);
        disable_LED(&PORTE, 5);
    }
}


/**
  * A cooperative "Pong" task.
  * Added testing code for LEDs.
  */
void Pong()
{
  init_LED_E3();
  for(;;) {
    enable_LED(&PORTE, 3);
    disable_LED(&PORTH, 3);
    disable_LED(&PORTG, 5);
    disable_LED(&PORTE, 5);
  }
}

void Paddle()
{
    init_LED_G5();
    for(;;)
    {
    //debug_led(1);
    enable_LED(&PORTG, 5);
    disable_LED(&PORTE, 3);
    disable_LED(&PORTH, 3);
    disable_LED(&PORTE, 5);

    //int x;
    //for (x = 0; x < (Now() / 10); x++)
    //{
    //    _delay_ms(1);
    //}
    _delay_ms(20);
    disable_LED(&PORTG, 5);

    Task_Next();
    }
}

void Puddle()
{
    init_LED_E5();
    for(;;)
    {
    debug_led(5);
    enable_LED(&PORTE, 5);
    disable_LED(&PORTE, 3);
    disable_LED(&PORTH, 3);

    _delay_ms(100);
    disable_LED(&PORTE, 5);

    Task_Next();
    }
}

void Test_Now()
{
    int threshold = 0;
    int x = 0;
    for(;;){
        if (Now() > threshold)
        {
            debug_led(x);
            threshold += 123;
            x += 1;
        }
    }
}

void UART_test()
{
	//char buf[MAXLINE];
    char buf[1];
	char byte;

	CLOCK_8MHZ();
	uart_init(UART_38400);
    //snprintf(buf, MAXLINE, "H");
    buf[0] = '!';
	uart_putstr(buf);
    for(;;)
    {
        //debug_led(1);
		if (uart_rx == 1) {
			byte = uart_getchar(uart_bytes_recv()-1);
            //debug_led(2);
			uart_rx = 0;
			_delay_ms(100);
			uart_putchar(byte);
            int byte_value = byte;
            debug_led(byte_value);
            if(byte_value == 33){
                debug_led(1);
                debug_led(2);
                debug_led(3);
            }
            if(byte == '!')
            {
                debug_led(3);
                debug_led(5);
            }
		}
        
        /*uart_init(UART_38400);       //From Neil's sample code.       
        uart_putchar('!');
        debug_led(2);
        uint8_t sent_uart = uart_get_byte(i++);
        debug_led(sent_uart);
        if (sent_uart){
            debug_led(5);
        }
        //debug_led(uart_get_byte(i++)); */
    }
}

void Read_Servo_Joystick ()
{
    //Set up the pins to read properly.
    //Set up input pin 22
    bit_reset(&DDRA, 0);
    bit_set(&PORTA, 0);
    int pina0;
    
    //Set up input pin A8
    bit_reset(&DDRK, 0);
    bit_set(&PORTK, 0);
    int y_pos;
    for(;;)
    {
        debug_led(5);
        //Read the button
        pina0 = PINA;
        pina0 = pina0 << 7;
        pina0 = pina0 >> 7;

        //Read the X

        //https://www.gammon.com.au/adc
        //Read the Y
        bit_set(&ADCSRA, 7);    //Turn on the ADC
        //Prescaler of 128
        bit_set(&ADCSRA, 0);
        bit_set(&ADCSRA, 1);
        bit_set(&ADCSRA, 2);
        
        //Set the channel to point at pin A8 (channel 8).
        bit_set(&ADCSRB, 3);
        
        // AVcc
        // 0 0 is internal ref turned off
        // 0 1 is avcc with external capacitor
        // 1 0 is internal 1.1 voltage reference with external capacitor
        // 1 1 is internal 2.56 volrage reference with external capacitor
        bit_reset(&ADMUX, 7);
        bit_set(&ADMUX, 6);
        
        //Start conversion
        bit_set(&ADCSRA, 6);

        //wait for conversion to finish
        int check_bit = ADCSRA;
        check_bit = ((check_bit) & (1<<(6)));
        while(check_bit != 0){
            debug_led(4);
            check_bit = ADCSRA;
            check_bit = ((check_bit) & (1<<(6)));
        }
        
        y_pos = ADC;


        // Optional: display the results.
        /*if(pina0 == 0){
            debug_led(10);
        }
        else
        {
            debug_led(5);
        }*/
        debug_led((y_pos / 100)+1);
        Task_Next();
    }
}




































void  Read_all_Joysticks(){
    //Set up the pins to read properly.
    //Set up input pin 22
    bit_reset(&DDRA, 0);
    bit_set(&PORTA, 0);
    int pina0;
    int result = 0;
    int check_bit;
    servo_x_pos = 47;
    servo_y_pos = 47;
    for(;;)
    {
        roomba_command = 'N';
        laser_state = 0;
        debug_led(1);
        //READ THE BUTTON (RIGHT JOYSTICK)
        pina0 = PINA;
        pina0 = pina0 << 7;
        pina0 = pina0 >> 7;
        laser_state = pina0;
        
        //SETUP ADC
        bit_set(&ADCSRA, 7);    //Turn on the ADC
        //Prescaler of 128
        bit_set(&ADCSRA, 0);
        bit_set(&ADCSRA, 1);
        bit_set(&ADCSRA, 2);
        
        //READ THE JOYSTICK PIN 11
        bit_set(&ADCSRB, 3);    //Set the channel to point at pin A11 (channel 11).
        bit_set(&ADMUX, 0);
        bit_set(&ADMUX, 1);
        bit_reset(&ADMUX, 2);
        bit_reset(&ADMUX, 3);
        bit_reset(&ADMUX, 4);
        bit_reset(&ADMUX, 7);   //SET AVCC 0 1
        bit_set(&ADMUX, 6);     //SET AVCC 0 1
        bit_set(&ADCSRA, 6);    //Start conversion
        check_bit = ADCSRA; //wait for Conversion to finish
        check_bit = ((check_bit) & (1<<(6)));
        while(check_bit != 0){
            check_bit = ADCSRA;
            check_bit = ((check_bit) & (1<<(6)));
        }
        result = ADC;
        result = (result / 100) + 1;    //1 to 6 to 11.
        
        if (result < 2){
            servo_x_pos++;
            if (servo_x_pos > 78){
                servo_x_pos = 78;
            }
        }
        else if (result > 10){
            servo_x_pos--;
            if (servo_x_pos < 16){
                servo_x_pos = 16;
            }
        }
        
        //READ THE JOYSTICK PIN 12
        bit_set(&ADCSRB, 3);    //Set the channel to point at pin A10 (channel 10).
        bit_reset(&ADMUX, 0);
        bit_set(&ADMUX, 1);
        bit_reset(&ADMUX, 2);
        bit_reset(&ADMUX, 3);
        bit_reset(&ADMUX, 4);
        bit_reset(&ADMUX, 7);   //SET AVCC 0 1
        bit_set(&ADMUX, 6);     //SET AVCC 0 1
        bit_set(&ADCSRA, 6);    //Start conversion
        check_bit = ADCSRA; //wait for Conversion to finish
        check_bit = ((check_bit) & (1<<(6)));
        while(check_bit != 0){
            check_bit = ADCSRA;
            check_bit = ((check_bit) & (1<<(6)));
        }
        result = ADC;
        result = (result / 100) + 1;    //1 to 6 to 11.
        
        if (result > 10){
            servo_y_pos++;
            if (servo_y_pos > 78){
                servo_y_pos = 78;
            }
        }
        else if (result < 2){
            servo_y_pos--;
            if (servo_y_pos < 16){
                servo_y_pos = 16;
            }
        }
        
        //READ THE JOYSTICK PIN 13
        int roomba_y;
        bit_set(&ADCSRB, 3);    //Set the channel to point at pin A9 (channel 9).
        bit_set(&ADMUX, 0);
        bit_reset(&ADMUX, 1);
        bit_reset(&ADMUX, 2);
        bit_reset(&ADMUX, 3);
        bit_reset(&ADMUX, 4);
        bit_reset(&ADMUX, 7);   //SET AVCC 0 1
        bit_set(&ADMUX, 6);     //SET AVCC 0 1
        bit_set(&ADCSRA, 6);    //Start conversion
        check_bit = ADCSRA; //wait for Conversion to finish
        check_bit = ((check_bit) & (1<<(6)));
        while(check_bit != 0){
            check_bit = ADCSRA;
            check_bit = ((check_bit) & (1<<(6)));
        }
        roomba_y = ADC;
        roomba_y = (roomba_y / 100) + 1;    //1 to 6 to 11.
        
        if (roomba_y < 2){
            roomba_command = 'F';
        }
        else if (roomba_y > 10){
            roomba_command = 'B';
        }
        
        //READ THE JOYSTICK PIN 14
        int roomba_x;
        bit_set(&ADCSRB, 3);    //Set the channel to point at pin A8 (channel 8).
        bit_reset(&ADMUX, 0);
        bit_reset(&ADMUX, 1);
        bit_reset(&ADMUX, 2);
        bit_reset(&ADMUX, 3);
        bit_reset(&ADMUX, 4);
        bit_reset(&ADMUX, 7);   //SET AVCC 0 1
        bit_set(&ADMUX, 6);     //SET AVCC 0 1
        bit_set(&ADCSRA, 6);    //Start conversion
        check_bit = ADCSRA; //wait for Conversion to finish
        check_bit = ((check_bit) & (1<<(6)));
        while(check_bit != 0){
            check_bit = ADCSRA;
            check_bit = ((check_bit) & (1<<(6)));
        }
        roomba_x= ADC;
        roomba_x = (roomba_x / 100) + 1;    //1 to 6 to 11.
        
        if (roomba_x < 2){
            roomba_command = 'R';
        }
        else if (roomba_x > 10){
            roomba_command = 'L';
        }

        Task_Next();
    }
}

void   Send_Info(){
    char buf[7];
    CLOCK_8MHZ();
    uart_init(UART_38400);
    for(;;)
    {
        debug_led(2);
        buf[0] = '$';                                       //CHECKED
        buf[1] = roomba_command;                            //CHECKED
        
        int servo_tens_x = servo_x_pos / 10;                  
        int servo_ones_x = servo_x_pos - (servo_tens_x * 10);
        buf[2] = (char)servo_tens_x; //servo x 10s            //CHECKED
        buf[3] = (char)servo_ones_x; //servo x 1s             //CHECKED
        
        int servo_tens_y = servo_y_pos / 10;
        int servo_ones_y = servo_y_pos - (servo_tens_y * 10);
        buf[4] = (char)servo_tens_y; //servo y 10s
        buf[5] = (char)servo_ones_y; //servo y 1s
        
        if (laser_state == 1){
            buf[6] = 'Z';
        }
        else {
            buf[6] = 'B';
        }
        
        //debug_led(buf[6]);
        
        uart_putstr(buf);
        
        Task_Next();
    }
}

void Idle_Task(){
    for(;;)
    {}
}

void a_main(){
    //ROUND ROBIN WITH PERIODIC AND SYSTEM
    /*Task_Create_RR( Pong, 100 );
    Task_Create_RR( Ping, 100 );
    Task_Create_Period( Paddle, 100, 100, 3, 1);
    Task_Create_System( Puddle, 100 ); */
    
    
    //MULTIPLE PRODUCERS ONE CONSUMER, ONE PRODUCER
    //DOES NOT MATCH MASK, OTHER DOES
    /*Task_Create_RR( Pong, 100 );
    Task_Create_System( Creator, 100 ); */
    
    //TEST ASYNC SEND
    //Task_Create_System( Creator2, 100 );
    
    //PERIODIC TASK TAKES LONGER THAN WCETI (os abort)
    //Task_Create_Period( Paddle, 100, 100, 1, 1);

    //CREATE MORE TASKS THAN THERE ARE SPACES FOR
    /*int x;
    for (x = 0; x < MAXTHREAD; x++){
        Task_Create_RR( Pong, 100 );
    }
    Task_Create_RR( Ping, 100 ); */
    
    //TEST NOW FUNCTION
    //Task_Create_RR(Test_Now, 100);
    
    //FIGURE OUT UART
    //Task_Create_RR(UART_test, 100);
    
    //FIGURE OUT JOYSTICK READING
    //Task_Create_Period ( Read_Servo_Joystick, 100, 5, 5, 1);
    //Task_Create_RR( Ping, 100 );
    
    //ACTUAL CODE START
    
    //Read the Joysticks
    Task_Create_Period ( Read_all_Joysticks, 100, 4, 1, 0);
    
    Task_Create_Period ( Send_Info, 100, 4, 1, 1);
    
    Task_Create_RR (Idle_Task, 100);
    
    
    //IDLE FROM NOW ON
    for(;;){
        Task_Next();
    }
}

//FIX DETECTING WHEN TWO PERIODIC TASKS COLLIDE




